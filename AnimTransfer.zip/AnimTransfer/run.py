from AnimTransfer import process
reload(process)

ui = process.anim_transfer()

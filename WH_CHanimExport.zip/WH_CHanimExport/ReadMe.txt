Установка

1 - сохранить всю папку [WH_CHanimExport] в: C:\Users\YOURUSERNAME\Documents\maya\scripts\

2 - Из папки [WH_CHanimExport] перетащить файл install.py в открытую Maya 

3 - На полке должна появиться зеленая иконка  Expot Anim
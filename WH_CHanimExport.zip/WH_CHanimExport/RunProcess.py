from WH_CHanimExport import CHAnimExportProcess
reload(CHAnimExportProcess)


CHAnimExportProcess.runProcess()